package com.javalec.friendsourcing.dto;

public class TagDto {
	private int FEED_FENUM;
	private String FOLLOWER;
	
	public TagDto() {
		// TODO Auto-generated constructor stub
	}
	
	public TagDto(int fEED_FENUM, String fOLLOWER) {
		super();
		FEED_FENUM = fEED_FENUM;
		FOLLOWER = fOLLOWER;
	}

	public int getFEED_FENUM() {
		return FEED_FENUM;
	}

	public void setFEED_FENUM(int fEED_FENUM) {
		FEED_FENUM = fEED_FENUM;
	}

	public String getFOLLOWER() {
		return FOLLOWER;
	}

	public void setFOLLOWER(String fOLLOWER) {
		FOLLOWER = fOLLOWER;
	}
	
	
}
