package com.javalec.friendsourcing.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.friendsourcing.dao.dao;
import com.javalec.friendsourcing.dto.CommentDto;
import com.javalec.friendsourcing.dto.FeedDto;
import com.javalec.friendsourcing.dto.FeedimgDto;
import com.javalec.friendsourcing.dto.FollowDto;
import com.javalec.friendsourcing.dto.HashTagDto;
import com.javalec.friendsourcing.dto.TagDto;
import com.javalec.friendsourcing.dto.feedLikeDto;
import com.javalec.friendsourcing.dto.memberDto;
import com.javalec.friendsourcing.dto.placeDto;

@Service
public class ServiceImpl implements service{
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public memberDto settings(HashMap<String, String> param) {
		System.out.println("settings() --> start  >>>> "+param.get("memId"));
		
		dao dao = sqlSession.getMapper(dao.class);
		memberDto dto = dao.settings(param);
		System.out.println(dto.getFilename());
		System.out.println(dto.getUuid());
		System.out.println(dto.getUploadpath());
		
		return dto;
	}
	
	@Override
	public ArrayList<FeedimgDto> settings2(HashMap<String, String> param) {
		System.out.println("settings2() --> start  >>>> ");
		
		dao dao = sqlSession.getMapper(dao.class);
		ArrayList<FeedimgDto> dtos = dao.settings2(param);
		
		System.out.println(dtos);
		System.out.println("settings2() --> end  >>>> ");
		return dtos;
	}
	//0607 ��� ���� �ҷ�����
	@Override
	public memberDto getMemInfo(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		memberDto dto = dao1.getMemInfo(param);
		
		return dto;
	}
	//0607 �ȷο� �ҷ����� 
	@Override
	public ArrayList<FollowDto> getFollowerSum(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<FollowDto> list = dao1.getFollowerSum(param);
		
		return list;
	}
	//0607 �ȷ��� �ҷ����� 
	@Override
	public ArrayList<FollowDto> getFollowingSum(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<FollowDto> list = dao1.getFollowingSum(param);
		
		return list;
	}
	//0607 �ȷο� ��� 
	@Override
	public memberDto getFollowerImg(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		memberDto dto = dao1.getFollowerImg(param);
		
		return dto;
	}
	
	//0607 �ȷ��� ��� 
	@Override
	public memberDto getFollowingImg(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		memberDto dto = dao1.getFollowingImg(param);
		
		return dto;
	}
	
	// 0607 ���������� �ǵ� �̹��� 
	@Override
	public FeedimgDto myPageListImg(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		FeedimgDto dto = dao1.myPageListImg(param);
		return dto;
	}
	// 0608 ���ƿ� ��������
	@Override
	public void likeUp(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.likeUp(param);
	}
	
	//0608 ���ƿ� �� �ҷ�����
	@Override
	public ArrayList<feedLikeDto> getLikeSum(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<feedLikeDto> list = dao1.getLikeSum(param);
		
		return list;
	}
	
	// 0608 ���ƿ� ����ϱ�
	@Override
	public void likeDown(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.likeDown(param);
	}
	
	@Override
	public FeedimgDto mainFeedListImg(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		FeedimgDto dto = dao1.mainFeedListImg(param);
		
		return dto;
	}
	
	@Override
	public memberDto getMemName(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		memberDto dto = dao1.getMemName(param);
		
		return dto;
	}
	
	
	@Override
	public ArrayList<FeedimgDto> coverImage(HashMap<String, String> param) {
		System.out.println("coverImage() --> start  >>>> ");
		
		dao dao = sqlSession.getMapper(dao.class);
		ArrayList<FeedimgDto> dtos = dao.coverImage(param);
		
		System.out.println(dtos);
		System.out.println("coverImage() --> end  >>>> ");
		return dtos;
	}

	@Override
	public Integer upload(HashMap<String, String> param) {
		System.out.println("service.upload() start");
		dao dao1 = sqlSession.getMapper(dao.class);
		Integer result = dao1.upload(param);
		System.out.println("service.upload() end");
		
		return result;
	}

	@Override
	public List<FeedDto> list() {
		dao dao1 = sqlSession.getMapper(dao.class);
		List<FeedDto> dtos = dao1.list(); 
		return dtos;
	}
	@Override
	public void profilesettings(HashMap<String, String> param) {
		System.out.println("profilesettings() --> start");
		System.out.println("@@@@@@#####>>>>>>>>>"+param.get("memName"));
		System.out.println("@@@@@@#####>>>>>>>>>"+param.get("memProfile"));
		System.out.println("@@@@@@#####>>>>>>>>>"+param.get("memId"));
		dao daos = sqlSession.getMapper(dao.class);
		daos.profilesettings(param);
		
	}
	
	// 0602
	@Override
	public memberDto checkImage(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		memberDto dto = dao1.checkImage(param);
		
		return dto;
	}
	
	@Override
	public void profilemodify(HashMap<String, String> param) {
		System.out.println("profilemodify() --> start");
		
		dao daos = sqlSession.getMapper(dao.class);
		daos.profilemodify(param);
		
	}
	@Override
	public void profilemodify2(HashMap<String, String> param) {
		System.out.println("profilemodify2() --> start");
		
		dao daos = sqlSession.getMapper(dao.class);
		daos.profilemodify2(param);
		
	}
	@Override
	public String checklg(String memId) {		
		
		dao daos = sqlSession.getMapper(dao.class);
		
		if (!memId.equals(daos.checklg(memId))) {
			return "null";
		}
		
		return daos.checklg(memId);
	}
	@Override
	public memberDto memXY(String memId) {
		System.out.println("@@@### => memxy start");
		dao dao1 = sqlSession.getMapper(dao.class);
		
		memberDto dto = dao1.memXY(memId);
		System.out.println("@@@### => memxy end : "+dto.getMemAddressX());
		return dto;
	}
	
	@Override
	public ArrayList<FeedDto> bringFollowMarker(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<FeedDto> list = dao1.bringFollowMarker(param);
		
		return list;
	}
	@Override
	public ArrayList<FeedDto> bringOtherPlanum() {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<FeedDto> list = dao1.bringOtherPlanum();
			
		return list;
	}
	
	@Override
	public placeDto bringOtherXY(int plaNum) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		placeDto dto = dao1.bringOtherXY(plaNum);
		
		return dto;
	}
	
	@Override
	public ArrayList<placeDto> myCluster2(HashMap<String, String> param) {

		dao dao1 = sqlSession.getMapper(dao.class);
		System.out.println("*********** param : "+param.get("plaNum"));
		ArrayList<placeDto> list = dao1.myCluster2(param);
		
		return list;
	}
	
	@Override
	public ArrayList<FeedDto> myCluster(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<FeedDto> list = dao1.myCluster(param);
		
		return list;
	}

	@Override
	public int contrastPlaceXY(HashMap<String, String> param) {
		System.out.println("==> contrastPlaceXY start");
		dao dao1 = sqlSession.getMapper(dao.class);
		int result = dao1.contrastPlaceXY(param);
		System.out.println("==> contrastPlaceXY end");
		
		return result;
	}

	@Override
	public int bringPlaceDB(HashMap<String, String> param) {
		System.out.println("==> bringPldaceDB start");
		dao dao1 = sqlSession.getMapper(dao.class);
		int result = dao1.bringPlaceDB(param);
		System.out.println("==> bringPldaceDB end");
		
		return result;
	}
	
	@Override
	public ArrayList<FeedDto> bringFeedNum(HashMap<String, String> param) {
		System.out.println("==> bringFeedNum start");
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<FeedDto> dto = dao1.bringFeedNum(param);
		System.out.println("==> bringFeedNum end");
		return dto;
	}

	@Override
	public int bringPlaceImg(String fenum) {
		System.out.println("==> bringPldaceDB start");
		dao dao1 = sqlSession.getMapper(dao.class);
		int result = dao1.bringPlaceImg(fenum);
		System.out.println("==> bringPldaceDB end");
		return result;
	}
	//�۾��� �޼��� 
		@Override
		public void write(HashMap<String, String> param) {
		
		System.out.println("@@@### FeedServiceImpl.write() start");
		dao dao = sqlSession.getMapper(dao.class);

		dao.write(param);
				
		System.out.println("@@@### FeedServiceImpl.write() end");
		}
		//��� ������� �޼���
		@Override
		public placeDto getPlaNum() {
			System.out.println("###@@@ --> getPlaNum() start");
			
			dao dao1 = sqlSession.getMapper(dao.class);
			placeDto dto = dao1.getPlaNum();
			System.out.println(dto.getPlaNum());
			
			System.out.println("###@@@ --> getPlaNum() end");
			return dto;
		}
		
		//�ǵ��ȣ ������� �޼���
		@Override
		public FeedDto getFeedNum() {
			System.out.println("###@@@ --> getFeedNum() start");
			
			dao dao1 = sqlSession.getMapper(dao.class);
			FeedDto dto = dao1.getFeedNum();
			
			System.out.println("###@@@ --> getFeedNum() end");
			return dto;
		}
		@Override
		public FeedDto contentView(HashMap<String, String> param) {
			System.out.println("@@@### --> contentView() start");
			
			dao dao1 = sqlSession.getMapper(dao.class);
			FeedDto dto= dao1.contentView(param);
			
			System.out.println("###@@@ --> contentView() end");
			return dto;
		}
		@Override
			public void modify(HashMap<String, String> param) {
			
			System.out.println("@@@### --> modify() start");
			
			dao dao1 = sqlSession.getMapper(dao.class);
			dao1.modify(param);
			
			System.out.println("###@@@ -->  modify() end");
			
		}

		@Override
		public void delete(HashMap<String, String> param) {
			System.out.println("@@@### --> ServiceImpl delete() start");
			dao dao1 = sqlSession.getMapper(dao.class);
			dao1.delete(param);
			
			System.out.println("###@@@ --> ServiceImpl delete() start");
		}
		@Override
		public ArrayList<FeedDto> mypageList(HashMap<String, String> param) {
			
			dao dao1 = sqlSession.getMapper(dao.class);
			ArrayList<FeedDto> list = dao1.mypageList(param);
			
			return list;
		}

		@Override
		public FeedDto viewFeedContent(HashMap<String, String> param) {
			dao dao1 = sqlSession.getMapper(dao.class);
			FeedDto dto = dao1.viewFeedContent(param);
			return dto;
		}

		@Override
		public ArrayList<placeDto> OtherCluster() {

			dao dao1 = sqlSession.getMapper(dao.class);
			ArrayList<placeDto> list = dao1.OtherCluster();
			
			return list;
		}

		@Override
		public ArrayList<placeDto> OtherCluster2(HashMap<String, String> param) {
			
			dao dao1 = sqlSession.getMapper(dao.class);
			System.out.println("*********** param : "+param.get("plaNum"));
			ArrayList<placeDto> list = dao1.OtherCluster2(param);
			
			return list;
		}
		

		@Override
		public ArrayList<FollowDto> bringFollower(HashMap<String, String> param) {

			dao dao1 = sqlSession.getMapper(dao.class);
			ArrayList<FollowDto> dto = dao1.bringFollower(param);
			
			return dto;
		}

		@Override
		public ArrayList<FeedDto> bringfollowerPlanum(HashMap<String, String> param) {

			dao dao1 = sqlSession.getMapper(dao.class);
			ArrayList<FeedDto> dto = dao1.bringfollowerPlanum(param);
			
			return dto;
		}

		@Override
		public ArrayList<placeDto> bringfollowerXY(HashMap<String, String> param) {
			
			dao dao1 = sqlSession.getMapper(dao.class);
			ArrayList<placeDto> dto = dao1.bringfollowerXY(param);
			
			return dto;
		}
		@Override
		public ArrayList<FeedDto> getFeedSum(HashMap<String, String> param) {
			dao dao1 = sqlSession.getMapper(dao.class);
			ArrayList<FeedDto> list = dao1.getFeedSum(param);
			
			return list;
		}
		
		// 0609 
		@Override
		public memberDto getMyimg(HashMap<String, String> param) {
			dao dao1 = sqlSession.getMapper(dao.class);
			memberDto dto = dao1.getMyimg(param);
			
			return dto;
		}
		

		@Override
		public String[] myLikeFeedNum(HashMap<String, String> param) {
			
			dao dao1 = sqlSession.getMapper(dao.class);
			String[] dto = dao1.myLikeFeedNum(param);
			
			return dto;
		}

		@Override
		public String[] myFeedNum(HashMap<String, String> param) {
			
			dao dao1 = sqlSession.getMapper(dao.class);
			String[] dto = dao1.myFeedNum(param);
			
			return dto;
		}

		@Override
		public String[] myTagFeedNum(HashMap<String, String> param) {
			
			dao dao1 = sqlSession.getMapper(dao.class);
			String[] dto = dao1.myTagFeedNum(param);
			
			return dto;
		}

		@Override
		public ArrayList<placeDto> LikeFeedXY(HashMap<String, String> param) {

			dao dao1 = sqlSession.getMapper(dao.class);
			ArrayList<placeDto> dto = dao1.LikeFeedXY(param);
					
			return dto;
		}
	//0609 �ȷο� �ϱ� 
	@Override
	public void follow(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.follow(param);
	}	
	
	//0609 �ȷο� ��� �ϱ� 
	@Override
	public void followOk(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.followOk(param);
	}	
	
	// 0609 �ȷο� üũ�ϱ� 
	@Override
	public int checkFollow(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		int count  = dao1.checkFollow(param);
		return count;
	}
	
	@Override
	public String[] getFeNumByHashTag(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		
		String[] dto = dao1.getFeNumByHashTag(param);
		return dto;
	}

	@Override
	public ArrayList<HashTagDto> getHashTag(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		
		ArrayList<HashTagDto> dto = dao1.getHashTag(param);
		
		return dto;
	}

	@Override
	public void insertMembership(HashMap<String, String> param) {

		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.insertMembership(param);
		
	}

	@Override
	public int getMembership(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		int result = dao1.getMembership(param);
		
		return result;
	}
	
	@Override
	public ArrayList<CommentDto> listComment(HashMap<String, String> param) {
		
		dao dao1 = sqlSession.getMapper(dao.class);
		ArrayList<CommentDto> dtos = dao1.listComment(param);
		
		return dtos;
	}

	@Override
	public void insertComment(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.insertComment(param);
	}


	@Override
	public void updateComment(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.updateComment(param);
	}

	@Override
	public void deleteComment(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.deleteComment(param);
	}

	@Override
	public int countComment(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		int result = dao1.countComment(param);
		
		return result;
	}
	
	@Override
	public void deleteimg(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.deleteimg(param);
	}

	@Override
	public void deletehastag(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.deletehastag(param);
	}

	@Override
	public void deletetag(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.deletetag(param);
	}

	@Override
	public void deletelike(HashMap<String, String> param) {
		dao dao1 = sqlSession.getMapper(dao.class);
		dao1.deletelike(param);
	}
	
	//0613�̹��� ����Ʈ ����
			@Override
			public ArrayList<FeedimgDto> contentView_img(HashMap<String, String> param) {
				System.out.println("@@@### --> ServiceImpl contentView_img() start");
				
				dao dao1 = sqlSession.getMapper(dao.class);
				System.out.println("%%%%--->param ���� �˱�����"+param.get("feed_fenum"));
				ArrayList<FeedimgDto> dto= dao1.contentView_img(param);
				
				/*
				 * System.out.println("�̹��� dto�� �� : "+dto.get(0).getImagenum());
				 * System.out.println("�̹��� dto�� �� : "+dto.get(1).getImagenum());
				 * System.out.println("�̹��� dto�� �� : "+dto.get(2).getImagenum());
				 * System.out.println("�̹��� dto�� �� : "+dto.get(3).getImagenum());
				 * System.out.println("�̹��� dto�� �� : "+dto.get(4).getImagenum());
				 */
				
				System.out.println("###@@@ -->  ServiceImpl contentView_img() end");
				return dto;
			}
			
			@Override
			public void deletecomments(HashMap<String, String> param) {
				dao dao1 = sqlSession.getMapper(dao.class);
				dao1.deletecomments(param);
			}
}

