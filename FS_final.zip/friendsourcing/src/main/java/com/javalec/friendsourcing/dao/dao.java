package com.javalec.friendsourcing.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.friendsourcing.dto.CommentDto;
import com.javalec.friendsourcing.dto.FeedDto;
import com.javalec.friendsourcing.dto.FeedimgDto;
import com.javalec.friendsourcing.dto.FollowDto;
import com.javalec.friendsourcing.dto.HashTagDto;
import com.javalec.friendsourcing.dto.TagDto;
import com.javalec.friendsourcing.dto.feedLikeDto;
import com.javalec.friendsourcing.dto.memberDto;
import com.javalec.friendsourcing.dto.placeDto;

public interface dao {
	
	public void register(HashMap<String, String> param);
	public memberDto settings(HashMap<String, String> param);
	public ArrayList<FeedimgDto> settings2(HashMap<String, String> param);
	public ArrayList<FeedimgDto> coverImage(HashMap<String, String> param);
	public Integer upload(HashMap<String, String> param);
	public List<FeedDto> list();
	public void profilesettings(HashMap<String, String> param);
	public void profilemodify(HashMap<String, String> param);
	public void profilemodify2(HashMap<String, String> param);
	public String checklg(@Param("memId") String memId);
	public memberDto memXY(String memId);
	public ArrayList<FeedDto> bringOtherPlanum();
	public placeDto bringOtherXY(int plaNum);
	public ArrayList<placeDto> OtherCluster();
	public ArrayList<placeDto> OtherCluster2(HashMap<String, String> param);
	public ArrayList<placeDto> myCluster2(HashMap<String, String> param);
	public ArrayList<FeedDto> myCluster(HashMap<String, String> param);
	public ArrayList<FeedDto> bringFollowMarker(HashMap<String, String> param);
	public int contrastPlaceXY(HashMap<String, String> param);
	public int bringPlaceDB(HashMap<String, String> param);
	public ArrayList<FeedDto> bringFeedNum(HashMap<String, String> param);
	public int bringPlaceImg(@Param("fenum") String fenum);
	//��� ��ȣ
	public placeDto getPlaNum();
	//�ǵ��ȣ
	public FeedDto getFeedNum();
	//�۾��� �޼��� 
	public void write(HashMap<String, String> param);
	//���� �ϱ� �� ���� ���̴� �ǵ�
	public FeedDto contentView(HashMap<String, String> param);
	//�����ϴ� �޼��� 
	public void modify(HashMap<String, String> param);
	//�����ϴ� �޼���
	public void delete(HashMap<String, String> param);
	public ArrayList<FeedDto> mypageList(HashMap<String, String> param);
	//0602 
	public memberDto checkImage(HashMap<String, String> param);
	public FeedDto viewFeedContent(HashMap<String, String> param);
	
	// ���� �ǵ� ����Ʈ �̹��� 
	public FeedimgDto mainFeedListImg(HashMap<String, String> param);
	
	// memId�� memName �ҷ����� 
	public memberDto getMemName(HashMap<String, String> param);
	//0607 ��� ���� �ҷ����� 
	public memberDto getMemInfo(HashMap<String, String> param);
	//0607 �ȷο� �ҷ����� 
	public ArrayList<FollowDto> getFollowerSum(HashMap<String, String> param);
	//0607 �ȷ��� �ҷ����� 
	public ArrayList<FollowDto> getFollowingSum(HashMap<String, String> param);
	// 0607 �ȷο� ���
	public memberDto getFollowerImg(HashMap<String, String> param);
	// 0607 �ȷ��� ���
	public memberDto getFollowingImg(HashMap<String, String> param);
	// 0607 ���������� �ǵ� �̹��� 
	public FeedimgDto myPageListImg(HashMap<String, String> param);
	// 0608 ���ƿ� �������� 
	public void likeUp(HashMap<String, String> param);
	// 0608 ���ƿ� �� �ҷ�����
	public ArrayList<feedLikeDto> getLikeSum(HashMap<String, String> param);
	// 0608 ���ƿ� ����ϱ� 
	public void likeDown(HashMap<String, String> param);
	// 0608 �ȷο� �ҷ�����
	public ArrayList<FollowDto> bringFollower(HashMap<String, String> param);
	// 0608 �ȷο� ��� �ҷ�����
	public ArrayList<FeedDto> bringfollowerPlanum(HashMap<String, String> param);
	// 0608 �ȷο� ��� ��ǥ �ҷ�����
	public ArrayList<placeDto> bringfollowerXY(HashMap<String, String> param);
	
	// 0608 �ǵ� �� �ҷ����� 
	public ArrayList<FeedDto> getFeedSum(HashMap<String, String> param);
	
	//0609 �� �̹��� �ҷ�����
	public memberDto getMyimg(HashMap<String, String> param);
	

	public String[] myLikeFeedNum(HashMap<String, String> param);

	public String[] myFeedNum(HashMap<String, String> param);

	public String[] myTagFeedNum(HashMap<String, String> param);
	
	public ArrayList<placeDto> LikeFeedXY(HashMap<String, String> param);
	
	//0609 �ȷο� �ϱ� 
	public void follow(HashMap<String, String> param);
	
	//0609 �ȷο�  ��� �ϱ� 
	public void followOk(HashMap<String, String> param);
	
	//0609 �ȷο� üũ�ϱ� 
	public int checkFollow(HashMap<String, String> param);
	
	public String[] getFeNumByHashTag(HashMap<String, String> param);
	
	public ArrayList<HashTagDto> getHashTag(HashMap<String, String> param);
	
	public void insertMembership(HashMap<String, String> param);
	
	public int getMembership(HashMap<String, String> param);
	
	//���
	public ArrayList<CommentDto> listComment(HashMap<String, String> param); //��� ���
	public void insertComment(HashMap<String, String> param); //��� �Է�
	public int countComment(HashMap<String, String> param); // ��� ����
	public void updateComment(HashMap<String, String> param); //��� ����
	public void deleteComment(HashMap<String, String> param); //��� ����
	
	//�߰�
	public void deleteimg(HashMap<String, String> param);
	public void deletehastag(HashMap<String, String> param);
	public void deletetag(HashMap<String, String> param);
	public void deletelike(HashMap<String, String> param);
	
	public ArrayList<FeedimgDto> contentView_img(HashMap<String, String> param);
	
	public void deletecomments(HashMap<String, String> param);
	
}
