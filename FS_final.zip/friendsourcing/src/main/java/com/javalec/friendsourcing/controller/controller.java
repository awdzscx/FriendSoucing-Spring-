package com.javalec.friendsourcing.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.mail.HtmlEmail;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javalec.friendsourcing.dao.dao;
import com.javalec.friendsourcing.dto.CommentDto;
import com.javalec.friendsourcing.dto.FeedDto;
import com.javalec.friendsourcing.dto.FeedimgDto;
import com.javalec.friendsourcing.dto.FollowDto;
import com.javalec.friendsourcing.dto.HashTagDto;
import com.javalec.friendsourcing.dto.email;
import com.javalec.friendsourcing.dto.feedLikeDto;
import com.javalec.friendsourcing.dto.memberDto;
import com.javalec.friendsourcing.dto.placeDto;
import com.javalec.friendsourcing.service.MailService;
import com.javalec.friendsourcing.service.service;
import com.javalec.friendsourcing.service.serviceTG;

@Controller
public class controller {
	
	@Autowired
	private SqlSession sqlSession;
	
	@Autowired
	private MailService mailService;
	
	@Autowired
	private service service;
	
	@Autowired
	private serviceTG serviceTG;
	
	// �ٸ���� ����������
	@RequestMapping("/anotherPage")
	public String anotherPage() {
		
		return "anotherPage";
	}
	
	@RequestMapping("/anotherPage1")
	public String anotherPage(HttpServletRequest request, Model model) {
		System.out.println("anotherPage --> start()");
		
		String anotherId = request.getParameter("anotherId");
		String memId = request.getParameter("memId");
				
		if (anotherId.equals(memId)) {
			return "redirect:mypage?memId="+memId;
		}
		
		System.out.println("anotherPage --> end()");
		
		return "redirect:anotherPage?anotherId="+anotherId;
	}
	
	// memId�� memName �޾ƿ��� 
	@RequestMapping(value="/getMemName", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public memberDto getMemName(@RequestParam HashMap<String, String> param){
		
		memberDto dto = service.getMemName(param);
		
		return dto;
	}
	
	
	@RequestMapping("/main")
	public String main(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		if (request.getParameter("memId")!= null) {
			//ȸ�� ���� �޾ƿ���
			HashMap<String, String> param = new HashMap<String, String>();
			param.put("memId", request.getParameter("memId"));
			System.out.println("param : "+param.get("memId"));
			
			memberDto dto = service.settings(param);
			String PullPath = dto.getUploadpath()+ "\\"+ dto.getUuid() + "_" +dto.getFilename();
			dto.setPullPath(URLEncoder.encode(PullPath,"utf-8"));
			
			model.addAttribute("dto", dto);
			
		}
		
		return "main";
	}
	
	@RequestMapping(value = "/mainFeedListImg", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public FeedimgDto mainFeedListImg(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException{
		
		FeedimgDto dto = service.mainFeedListImg(param);
			String pullpath = dto.getUploadPath()+"\\"+dto.getUuid()+"_"+dto.getFileName();
			System.out.println("mainFeedListimg ---->"+pullpath);
			dto.setPullPath(URLEncoder.encode(pullpath,"utf-8"));
		
		return dto;
	}
	
	@RequestMapping(value = "/listImage", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<FeedimgDto> settings2(@RequestParam HashMap<String, String> param, Model model) throws UnsupportedEncodingException{
		
		ArrayList<FeedimgDto> feeddto = service.settings2(param);
		
		for (int i = 0; i < feeddto.size(); i++) {
			String PullPath = feeddto.get(i).getUploadPath()+ "\\"+ feeddto.get(i).getUuid() + "_" +feeddto.get(i).getFileName();
			System.out.println(PullPath);
			feeddto.get(i).setPullPath(URLEncoder.encode(PullPath,"utf-8"));
		}
		
		
		return feeddto;
	}
	
	@RequestMapping("/login")
	public String login(HttpServletRequest request, Model model) {
		
		if (request.getParameter("memId")!= null) {
			request.getSession().setAttribute("memId", request.getParameter("memId"));
			model.addAttribute("login", true);
		}
		return "redirect:main?memId="+request.getParameter("memId");
	}
	
	@RequestMapping("/lg")
	public String lg(@RequestParam HashMap<String, String> param, Model model) throws Exception{
		String reciver = param.get("memId");
		String content = "http://localhost:8182/friendsourcing/login";
		String title = "FriendSoucing �α��� ��ũ�Դϴ�.";
		
		dao dao = sqlSession.getMapper(dao.class);
		
		if (service.checklg(reciver).equals("null")) {
			return "redirect:register?memId="+reciver;
		}
		
		// Mail Server ����
		String charSet = "utf-8";
		String hostSMTP = "smtp.naver.com";		
		String hostSMTPid = "fsourcing@naver.com"; // ������ ���̵� �Է�		
		String hostSMTPpwd = "Fs2022!!"; // ��й�ȣ �Է�
		
		// ������ ��� EMail, ����, ���� 
		String fromEmail = "fsourcing@naver.com"; // ������ ��� eamil
		String fromName = "fsAdmin";  // ������ ��� �̸�
		String subject = "Friendsourcing �α��� ��ũ�Դϴ�."; // ����
		
		
		try {
			HtmlEmail email = new HtmlEmail();
			email.setDebug(true);
			email.setCharset(charSet);
			email.setSSL(true);
			email.setHostName(hostSMTP);
			email.setSmtpPort(587);	// SMTP ��Ʈ ��ȣ �Է�

			email.setAuthentication(hostSMTPid, hostSMTPpwd);
			email.setTLS(true);
			email.addTo(reciver, charSet);
			email.setFrom(fromEmail, fromName, charSet);
			email.setSubject(subject);
			email.setHtmlMsg("<a href='"+content+"?memId="+reciver+"'>Fs �α��� �ϱ�</a>"); // ���� ����
			email.send();			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return "redirect:main";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request){
		request.getSession().removeAttribute("memId");
		
		return "redirect:main";
	}
	
	@RequestMapping("/settings")
	public String settings(@RequestParam HashMap<String, String> param, Model model) throws UnsupportedEncodingException {
		memberDto dto = service.settings(param);
		
		String PullPath = dto.getUploadpath()+ "\\"+ dto.getUuid() + "_" +dto.getFilename();
		dto.setPullPath(URLEncoder.encode(PullPath,"utf-8"));
		model.addAttribute("dto", dto);
		
		return "settings";
	}
	//0609 �ȷο� ���� üũ�ϱ� 
	@RequestMapping(value = "checkFollow", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public int  checkFollow(@RequestParam HashMap<String, String> param) {
		System.out.println("checkFollow ���� !!!");
		
		int count = service.checkFollow(param);
		
		System.out.println("checkFollow �Ϸ� !!!");
		
		return count;
	}
	
	//0609 �ȷο� �ϱ� 
	@RequestMapping(value = "follow", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public void follow(@RequestParam HashMap<String, String> param) {
		System.out.println("follow���� !!!");
		service.follow(param);
		System.out.println("follow����!!!!");
	}
	
	//0609 �ȷο� ��� �ϱ� 
	@RequestMapping(value = "followOk", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public void followOk(@RequestParam HashMap<String, String> param) {
		System.out.println("followOk ���� !!!");
		service.followOk(param);
		System.out.println("followOk ����!!!!");
	}
	
	//0607 ��� ���� �ҷ� ���� 
	@RequestMapping(value="getMemInfo", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public memberDto getMemInfo(@RequestParam HashMap<String, String> param) {
		
		memberDto dto = service.getMemInfo(param);
		
		return dto;
	}
	//0607 �ȷο��� 
	@RequestMapping(value="getFollowerSum", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<FollowDto> getFollowerSum(@RequestParam HashMap<String, String> param) {
		
		ArrayList<FollowDto> list = service.getFollowerSum(param);
		
		return list;
	}
	//0607 �ȷ��׼� 
	@RequestMapping(value="getFollowingSum", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<FollowDto> getFollowingSum(@RequestParam HashMap<String, String> param) {
		
		ArrayList<FollowDto> list = service.getFollowingSum(param);
		
		return list;
	}
	
	//0607 �ȷο� ���
	@RequestMapping(value="getFollowerImg", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public memberDto getFollowerImg(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		memberDto dto = service.getFollowerImg(param);
		
		String PullPath = dto.getUploadpath()+ "\\"+ dto.getUuid() + "_" +dto.getFilename();
		dto.setPullPath(URLEncoder.encode(PullPath,"utf-8"));
		
		return dto;
	}
	
	//0607 �ȷ��� ���
	@RequestMapping(value="getFollowingImg", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public memberDto getFollowingImg(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		memberDto dto = service.getFollowingImg(param);
		
		String PullPath = dto.getUploadpath()+ "\\"+ dto.getUuid() + "_" +dto.getFilename();
		dto.setPullPath(URLEncoder.encode(PullPath,"utf-8"));
		
		return dto;
	}
	
	//0607 ���������� �ǵ� �̹��� (��������) 
	@RequestMapping(value="myPageListImg", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public FeedimgDto myPageListImg(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
		FeedimgDto dto = service.myPageListImg(param);
		
		String pullpath = dto.getUploadPath()+"\\"+dto.getUuid()+"_"+dto.getFileName();
		System.out.println("mainFeedListimg ---->"+pullpath);
		dto.setPullPath(URLEncoder.encode(pullpath,"utf-8"));
		
		return dto;
	}
	
	//0608 ���ƿ� ��������
	@RequestMapping(value="likeUp", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public void likeUp(@RequestParam HashMap<String, String> param) {
		service.likeUp(param);
		
		System.out.println("likeup() ����");
	}
	
	//0608 �ǵ� ���� ���ƿ� �� �ҷ����� getLikeSum
	@RequestMapping(value="getLikeSum", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<feedLikeDto> getLikeSum(@RequestParam HashMap<String, String> param) {
		
		System.out.println("getLikeSum -->" + param);
		ArrayList<feedLikeDto> list = service.getLikeSum(param);
		
		System.out.println("getLikeSum() ����"+ list.size());
		return list;
	}
	// 0608 ���ƿ� ����ϱ�
	@RequestMapping(value="likeDown", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public void likeDown(@RequestParam HashMap<String, String> param) {
		service.likeDown(param);
		
		System.out.println("likeDown() ����");
	}
	
	@RequestMapping(value="/profilesettings")
	public String profilesettings(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### param@@@@"+param.get("memId"));
		System.out.println("@@@### param@@@@"+param.get("memProfile"));
		
		service.profilesettings(param);
		
		return "redirect:settings?memId="+param.get("memId");
	}
	
	@RequestMapping(value="/profilemodify")
	public String profilemodify(@RequestParam HashMap<String, String> param, Model model) {
		
		service.profilemodify(param);
		
		return "redirect:settings?memId="+param.get("memId");
	}
	@RequestMapping(value="/profilemodify2")
	public String profilemodify2(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("@@@### param@@@@"+param.get("memAddress"));
		System.out.println("@@@### param@@@@"+param.get("memAddressX"));
		System.out.println("@@@### param@@@@"+param.get("memAddressY"));
		
		service.profilemodify2(param);
		
		return "redirect:settings?memId="+param.get("memId");
	}
	@RequestMapping("/search")
	public String search(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		
		if (request.getParameter("memId")!= null) {
			//ȸ�� ���� �޾ƿ���
			HashMap<String, String> param = new HashMap<String, String>();
			param.put("memId", request.getParameter("memId"));
			System.out.println("param : "+param.get("memId"));
			
			memberDto dto = service.settings(param);
			String PullPath = dto.getUploadpath()+ "\\"+ dto.getUuid() + "_" +dto.getFilename();
			dto.setPullPath(URLEncoder.encode(PullPath,"utf-8"));
			
			model.addAttribute("dto", dto);
		}
		return "search";
	}
	
	@RequestMapping("/mypage")
	public String mypage(HttpServletRequest request, Model model) throws UnsupportedEncodingException {
		
		if (request.getParameter("memId")!= null) {
			//ȸ�� ���� �޾ƿ���
			HashMap<String, String> param = new HashMap<String, String>();
			param.put("memId", request.getParameter("memId"));
			System.out.println("param : "+param.get("memId"));
			
			memberDto dto = service.settings(param);
			String PullPath = dto.getUploadpath()+ "\\"+ dto.getUuid() + "_" +dto.getFilename();
			dto.setPullPath(URLEncoder.encode(PullPath,"utf-8"));
			
			model.addAttribute("dto", dto);
		}
		
		return "mypage";
	}
	
	@RequestMapping("/register")
	public String register(@RequestParam HashMap<String, String> param, Model model) throws Exception{
		String reciver = param.get("memId");
		String content = "http://localhost:8182/friendsourcing/login";
		String title = "FriendSoucing �α��� ��ũ�Դϴ�.";
		
		// db�� ���̵� �߰�
		dao dao = sqlSession.getMapper(dao.class);
		
		//id �ߺ�üũ �˻�
		if (service.checklg(reciver).equals("null")) {
			//ȸ������
			String memId =  param.get("memId");
			String memName = memId.substring(0, memId.indexOf("@"));
			param.put("memName", memName);
			
			dao.register(param);
		}
		
		// Mail Server ����
		String charSet = "utf-8";
		String hostSMTP = "smtp.naver.com";		
		String hostSMTPid = "fsourcing@naver.com"; // ������ ���̵� �Է�		
		String hostSMTPpwd = "Fs2022!!"; // ��й�ȣ �Է�
		
		// ������ ��� EMail, ����, ����
		String fromEmail = "fsourcing@naver.com"; // ������ ��� eamil
		String fromName = "fsAdmin";  // ������ ��� �̸�
		String subject = "Friendsourcing ȸ�������� �����մϴ�."; // ����
		
		
		try {
			HtmlEmail email = new HtmlEmail();
			email.setDebug(true);
			email.setCharset(charSet);
			email.setSSL(true);
			email.setHostName(hostSMTP);
			email.setSmtpPort(587);	// SMTP ��Ʈ ��ȣ �Է�
			email.setAuthentication(hostSMTPid, hostSMTPpwd);
			email.setTLS(true);
			email.addTo(reciver, charSet);
			email.setFrom(fromEmail, fromName, charSet);
			email.setSubject(subject);
			email.setHtmlMsg("<a href='"+content+"?memId="+reciver+"'>Fs �α��� �ϱ�</a>"); // ���� ����
			email.send();			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return "redirect:main";
	}
	
	@RequestMapping("upload")
	public String FeedUpload(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("upload() start");
		service.upload(param);
		
		System.out.println("upload() end");
		return "redirect:main";
	}
	
	@RequestMapping("placeUpload")
	public String jsp1() {
		return "placeUpload";
	}
	
	@RequestMapping(value = "/getPlaNum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public placeDto getPlaNum() {
		System.out.println("@@## --> getPlaNum start");
		
		placeDto dto = service.getPlaNum();
		
		System.out.println(dto.getPlaNum());
		System.out.println("@@## --> getPlaNum end");
		
		return dto;
	}
	
	@RequestMapping(value = "/getFeedNum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public FeedDto getFeedNum() {
		System.out.println("@@## --> getFeedNum start");
		
		FeedDto dto = service.getFeedNum();
		
		System.out.println("@@## --> getFeedNum end");
		
		return dto;
	}
	
	@RequestMapping(value = "/cont", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public List<FeedDto> cont() {
		List<FeedDto> dtos = service.list();
		System.out.println("@@@### = > dtos");
		return dtos;
	}
	
	@RequestMapping(value = "/bringFollowMarker", method = RequestMethod.POST, produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<FeedDto> bringFollowMarker(@RequestParam HashMap<String, String> param, Model model){
		System.out.println("@@@### --> bringFollowMarker() start");
		
		ArrayList<FeedDto> list = service.bringFollowMarker(param);
		
		System.out.println("@@@### --> bringFollowMarker() end");
		
		return list;
	}

	@RequestMapping(value = "/bringMemXY", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public memberDto bringMemXY(HttpServletRequest request, Model model) {
		System.out.println("@@@### = > memXY start");
		System.out.println(request.getParameter("memId"));
		memberDto memXY = service.memXY(request.getParameter("memId"));
		
		model.addAttribute("memdto", memXY);
		
		System.out.println("@@@### = > memXY end");
		return memXY;
	}
	
	@RequestMapping(value = "/bringOtherPlanum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<FeedDto> bringOtherXY(Model model) {
		System.out.println("@@@### = > bringOtherPlanum start");
		
		ArrayList<FeedDto> list = service.bringOtherPlanum();
		
		//System.out.println(list.get(0).getPlace_planum());
		//System.out.println(list.get(0).getMarkertype());
		//System.out.println(list.get(1).getPlace_planum());
		//System.out.println(list.get(1).getMarkertype());
		//System.out.println("@@@### = > bringOtherPlanum end");
		return list;
	}
	
	@RequestMapping(value = "/bringOtherXY", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public placeDto bringOtherXY(HttpServletRequest request, Model model){
		System.out.println("@@@### --> bringOtherXY start");
		int plaNum = Integer.parseInt(request.getParameter("plaNum"));
		System.out.println(plaNum);
		
		placeDto dto = service.bringOtherXY(plaNum);
		System.out.println(dto.getPlaX());
		System.out.println(dto.getPlaY());
		
		
		System.out.println("@@@### --> bringOtherXY end");
		
		return dto;
	}
	@RequestMapping(value="/OtherCluster", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<placeDto> OtherCluster(){
		System.out.println("@@@### ==> OtherCluster start");
		
		ArrayList<placeDto> list = service.OtherCluster();
		
		System.out.println("@@@### ==> OtherCluster end");
		
		return list;
	}
	
	@RequestMapping(value = "/myCluster2", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public List<placeDto> myCluster2(@RequestParam HashMap<String, String> param){
		System.out.println("@@@### ==> mycluster2 start");
		
		List<placeDto> list = service.myCluster2(param);
		
		System.out.println("@@@### ==> mycluster2 end");
		
		return list;
	}
	@RequestMapping(value = "/OtherCluster2", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<placeDto> OtherCluster2(@RequestParam HashMap<String, String> param){
		System.out.println("@@@### ==> OtherCluster2 start");
		
		ArrayList<placeDto> dto = service.OtherCluster2(param);
		
		System.out.println("@@@### ==> OtherCluster2 end");
		
		return dto;
	}
	
	@RequestMapping(value="/myCluster", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public List<FeedDto> myCluster(@RequestParam HashMap<String, String> param){
		System.out.println("@@@### ==> mycluster start");
		System.out.println("param : "+ param.get("member_memid"));
		
		List<FeedDto> list = service.myCluster(param);
		
		System.out.println("@@@### ==> mycluster end");
		
		return list;
	}
	

	@RequestMapping(value = "/contrast", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public int contrastPlaceXY(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("==> contrastPlaceXY start");
		
		int result = service.contrastPlaceXY(param);
		System.out.println(param);
		System.out.println(result);
		System.out.println("==> contrastPlaceXY end");
		return result;
	}

	@RequestMapping(value = "/bringPlaceDB", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public int bringPlaceDB(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("==> bringPlaceDB start");

		int result = service.bringPlaceDB(param);
		
		System.out.println("==> bringPlaceDB end");
		
		return result;
	}
	
	@RequestMapping(value = "/bringFeedNum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<FeedDto> bringFeedNum(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("==> bringFeedNum start");
		
		ArrayList<FeedDto> result = service.bringFeedNum(param);
		System.out.println(param.get("PLANUM"));
		
		System.out.println("==> bringFeedNum end");
		System.out.println(result.get(0).getFenum());
		
		return result;
	}

	@RequestMapping(value = "/bringPlaceImg", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public int bringPlaceImg(@RequestParam HashMap<String, String> param, Model model) {
		System.out.println("==> bringPlaceImg start");
		
		String fenum = param.get("fenum");
		int result = service.bringPlaceImg(fenum);
		System.out.println(param);
		
		System.out.println("==> bringPlaceImg end");
		
		return result;
	}
	
	//�ǵ� �۾��� �޼��� 
	@RequestMapping(value = "write", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public String write(@RequestParam HashMap<String, String> param) {
		
		System.out.println("@@@### Controller.write() start");
		service.write(param);
		System.out.println("@@@### Controller.write() end");
		System.out.println("feedNum : "+serviceTG.feedNum());
		
		return serviceTG.feedNum();
	}
		
	@RequestMapping(value = "mypageList", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public ArrayList<FeedDto> mypageList(@RequestParam HashMap<String, String> param) {
		System.out.println("mypageList --> start");
		System.out.println(param);
		System.out.println(param.get("member_memid"));
		
		ArrayList<FeedDto> list = service.mypageList(param);
		
		System.out.println("mypageList --> end");
		return list;
	}
	// 0602 �̹��� �ִ��� üũ 
	@RequestMapping(value = "checkImage", method = RequestMethod.POST,produces = "application/json; charset=utf8")
	@ResponseBody
	public memberDto checkImage(@RequestParam HashMap<String, String> param){
		System.out.println("checkImage() -> start");
		
		memberDto dto = service.checkImage(param);
		
		System.out.println("checkImage() -> end");
		return dto;
	}	
	
	//���ѽ�ũ��
		@RequestMapping(value = "feedList", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public ArrayList<FeedDto> page(@RequestParam HashMap<String, String> param) {
			
			ArrayList<FeedDto> list = new ArrayList<FeedDto>();
			
			//�������� �޾ƿ� �ǵ� ���� 
			final int PAGE_ROW_COUNT = 6;
			
			int pageNum = 1;
			String strPageNum = param.get("pageNum");
			if (strPageNum != null) {
				pageNum = Integer.parseInt(strPageNum);
			}
			int startRowNum = 0;
			//������ �������� ���� �ǵ� - 0���� ����
			if (pageNum!=1) {
				startRowNum = 1 +(pageNum - 1) * PAGE_ROW_COUNT;
			}
			//������ �������� �� �ǵ�
			int endRowNum = pageNum * PAGE_ROW_COUNT;
			
			//int rowCount = PAGE_ROW_COUNT;
			
			//���ǵ� ����
			int totalRow = Integer.parseInt(serviceTG.feedCount());
			int totlaPageCount = (int) Math.ceil(totalRow/(double) PAGE_ROW_COUNT);
			
			//�������� �Ѿ ���
			if (totlaPageCount < pageNum) {
				return null;
			}
			
			list = serviceTG.feedList(startRowNum, endRowNum);
			
			return list;
		}
		
		@RequestMapping(value = "/viewFeedContent", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public FeedDto viewFeedContent(@RequestParam HashMap<String, String> param) {
			System.out.println("@@## --> viewFeedContent start");
			System.out.println(param);
			
			FeedDto dto = service.viewFeedContent(param);
			System.out.println(dto);
			
			System.out.println("@@## --> viewFeedContent end");
			
			return dto;
		}
		
		//�� �ǵ� �ȷο� �ǵ� ��ũ��
		@RequestMapping(value = "followfeedList", method = RequestMethod.POST, produces = "application/json; charset=utf8")
		@ResponseBody
		public ResponseEntity<ArrayList<FeedDto>> followpage(String pageNum,String member_memid,String[] follower_id) {
			ArrayList<FeedDto> list = new ArrayList<FeedDto>();
			System.out.println("%!##@$!#%!#%$%#: "+pageNum);
			System.out.println("!#!@@!%!@%@#%#%: "+follower_id[0]);
			
			//�������� �޾ƿ� �ǵ� ���� 
			final int PAGE_ROW_COUNT = 6;
			
			int jpageNum = 1;
			String strPageNum = pageNum;
			if (strPageNum != null) {
				jpageNum = Integer.parseInt(strPageNum);
			}
			int startRowNum = 0;
			//������ �������� ���� �ǵ� - 0���� ����
			if (jpageNum!=1) {
				startRowNum = 1 +(jpageNum - 1) * PAGE_ROW_COUNT;
			}
			//������ �������� �� �ǵ�
			int endRowNum = jpageNum * PAGE_ROW_COUNT;
			
			//int rowCount = PAGE_ROW_COUNT;
			
			//���ǵ� ����
			int totalRow = Integer.parseInt(serviceTG.feedCount());
			int totlaPageCount = (int) Math.ceil(totalRow/(double) PAGE_ROW_COUNT);
			
			//�������� �Ѿ ���
			if (totlaPageCount < jpageNum) {
				return null;
			}
			
			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("startRowNum", Integer.toString(startRowNum));
			param.put("endRowNum", Integer.toString(endRowNum));
			param.put("follower_id", follower_id);
			param.put("member_memid", member_memid);
			
			list = serviceTG.followfeedList(param);
			System.out.println("feedList end");
			return new ResponseEntity<ArrayList<FeedDto>>(list, HttpStatus.OK);
		}
		
		
		
		//follow ��� 6/7
		@RequestMapping(value = "feedFollow", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public int feedFollow(@RequestParam HashMap<String, String> param) {
			System.out.println("param follower : "+param.get("follower"));
			System.out.println("param member_memid : "+param.get("member_memid"));
			
			return serviceTG.feedFollow(param);
		}
		
		//followListView
				@RequestMapping(value = "followListView", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public String[] followListView(@RequestParam HashMap<String, String> param) {
					System.out.println("param member_memid : "+param.get("member_memid"));
					String[] list = serviceTG.followListView(param);
					
					return list;
				}
		
		//followDelete
		@RequestMapping(value = "followDelete", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public int followDelete(@RequestParam HashMap<String, String> param) {
			System.out.println("param follower : "+param.get("follower"));
			System.out.println("param member_memid : "+param.get("member_memid"));
			
			return serviceTG.followDelete(param);
		}
		
		@RequestMapping(value = "/coverImage", method = RequestMethod.POST, produces = "application/json; charset=utf8")
		@ResponseBody
		public ArrayList<FeedimgDto> coverImage(@RequestParam HashMap<String, String> param, Model model) throws UnsupportedEncodingException{
			
			ArrayList<FeedimgDto> feeddto = service.coverImage(param);
			
			for (int i = 0; i < feeddto.size(); i++) {
				String PullPath = feeddto.get(i).getUploadPath()+ "\\"+ feeddto.get(i).getUuid() + "_" +feeddto.get(i).getFileName();
				System.out.println(PullPath);
				feeddto.get(i).setPullPath(URLEncoder.encode(PullPath,"utf-8"));
			}
			
			
			return feeddto;
		}
		
		//bringFollower
		@RequestMapping(value = "bringFollower", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public ArrayList<FollowDto> bringFollower(@RequestParam HashMap<String, String> param) {
			
			System.out.println("bringFollower => start");
			
			ArrayList<FollowDto> dto = service.bringFollower(param);
			System.out.println("bringFollower=>"+dto);
			
			
			System.out.println("bringFollower => end");
			
			return dto;
		}

		//bringfollowerPlanum
		@RequestMapping(value = "bringfollowerPlanum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public ArrayList<FeedDto> bringfollowerPlanum(@RequestParam HashMap<String, String> param) {
			
			System.out.println("bringfollowerPlanum => start");
			
			ArrayList<FeedDto> dto = service.bringfollowerPlanum(param);
			System.out.println(dto);
			
			
			System.out.println("bringfollowerPlanum => end");
			
			return dto;
		}

		//bringfollowerPlanum
		@RequestMapping(value = "bringfollowerXY", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public ArrayList<placeDto> bringfollowerXY(@RequestParam HashMap<String, String> param) {
			
			System.out.println("bringfollowerXY => start");
			
			ArrayList<placeDto> dto = service.bringfollowerXY(param);
			System.out.println(dto);
			
			
			System.out.println("bringfollowerXY => end");
			
			return dto;
		}
		
		//0608 �ǵ�� �ҷ����� 
		@RequestMapping(value = "getFeedSum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public ArrayList<FeedDto> getFeedSum(@RequestParam HashMap<String, String> param){
			ArrayList<FeedDto> list = service.getFeedSum(param);
			
			return list;
		}
		
		//0609 �� �̹��� �ҷ����� 
		@RequestMapping(value = "getMyimg", method = RequestMethod.POST,produces = "application/json; charset=utf8")
		@ResponseBody
		public memberDto getMyimg(@RequestParam HashMap<String, String> param) throws UnsupportedEncodingException {
			memberDto dto = service.getMyimg(param);
			
			String PullPath = dto.getUploadpath()+ "\\"+ dto.getUuid() + "_" +dto.getFilename();
			dto.setPullPath(URLEncoder.encode(PullPath,"utf-8"));
			
			return dto;
		}
		
		//0609 �߰� start
		
				//�� �ǵ� �ȷο� �ǵ� ��ũ��
				@RequestMapping(value = "myLikeFeedList", method = RequestMethod.POST, produces = "application/json; charset=utf8")
				@ResponseBody
				public ResponseEntity<ArrayList<FeedDto>> myLikeFeedList(String pageNum, String[] feNum) {
					ArrayList<FeedDto> list = new ArrayList<FeedDto>();
					System.out.println("%!##@$!#%!#%$%#: "+pageNum);
					System.out.println("!#!@@!%!@%@#%#%: "+feNum[0]);
					
					//�������� �޾ƿ� �ǵ� ���� 
					final int PAGE_ROW_COUNT = 6;
					
					int jpageNum = 1;
					String strPageNum = pageNum;
					if (strPageNum != null) {
						jpageNum = Integer.parseInt(strPageNum);
					}
					int startRowNum = 0;
					//������ �������� ���� �ǵ� - 0���� ����
					if (jpageNum!=1) {
						startRowNum = 1 +(jpageNum - 1) * PAGE_ROW_COUNT;
					}
					//������ �������� �� �ǵ�
					int endRowNum = jpageNum * PAGE_ROW_COUNT;
					
					//int rowCount = PAGE_ROW_COUNT;
					
					//���ǵ� ����
					int totalRow = Integer.parseInt(serviceTG.feedCount());
					int totlaPageCount = (int) Math.ceil(totalRow/(double) PAGE_ROW_COUNT);
					
					//�������� �Ѿ ���
					if (totlaPageCount < jpageNum) {
						return null;
					}
					
					HashMap<String, Object> param = new HashMap<String, Object>();
					param.put("startRowNum", Integer.toString(startRowNum));
					param.put("endRowNum", Integer.toString(endRowNum));
					param.put("feNum", feNum);
					
					list = serviceTG.myLikeFeedList(param);
					System.out.println("myLikeFeedList end");
					return new ResponseEntity<ArrayList<FeedDto>>(list, HttpStatus.OK);
				}
				
				//�� �ǵ� ��ũ��
				@RequestMapping(value = "myFeedList", method = RequestMethod.POST, produces = "application/json; charset=utf8")
				@ResponseBody
				public ResponseEntity<ArrayList<FeedDto>> myFeedList(String pageNum, String[] feNum) {
					ArrayList<FeedDto> list = new ArrayList<FeedDto>();
					
					//�������� �޾ƿ� �ǵ� ���� 
					final int PAGE_ROW_COUNT = 6;
					
					int jpageNum = 1;
					String strPageNum = pageNum;
					if (strPageNum != null) {
						jpageNum = Integer.parseInt(strPageNum);
					}
					int startRowNum = 0;
					//������ �������� ���� �ǵ� - 0���� ����
					if (jpageNum!=1) {
						startRowNum = 1 +(jpageNum - 1) * PAGE_ROW_COUNT;
					}
					//������ �������� �� �ǵ�
					int endRowNum = jpageNum * PAGE_ROW_COUNT;
					
					//int rowCount = PAGE_ROW_COUNT;
					
					//���ǵ� ����
					int totalRow = Integer.parseInt(serviceTG.feedCount());
					int totlaPageCount = (int) Math.ceil(totalRow/(double) PAGE_ROW_COUNT);
					
					//�������� �Ѿ ���
					if (totlaPageCount < jpageNum) {
						return null;
					}
					
					HashMap<String, Object> param = new HashMap<String, Object>();
					param.put("startRowNum", Integer.toString(startRowNum));
					param.put("endRowNum", Integer.toString(endRowNum));
					param.put("feNum", feNum);
					
					list = serviceTG.myFeedList(param);
					System.out.println("myFeedList end");
					return new ResponseEntity<ArrayList<FeedDto>>(list, HttpStatus.OK);
				}
				

				
				//�±׵� �ǵ� ��ũ��
				@RequestMapping(value = "myTagFeedList", method = RequestMethod.POST, produces = "application/json; charset=utf8")
				@ResponseBody
				public ResponseEntity<ArrayList<FeedDto>> myTagFeedList(String pageNum, String[] feNum) {
					ArrayList<FeedDto> list = new ArrayList<FeedDto>();
					System.out.println("%!##@$!#%!#%$%#: "+pageNum);
					System.out.println("!#!@@!%!@%@#%#%: "+feNum[0]);
					
					//�������� �޾ƿ� �ǵ� ���� 
					final int PAGE_ROW_COUNT = 6;
					
					int jpageNum = 1;
					String strPageNum = pageNum;
					if (strPageNum != null) {
						jpageNum = Integer.parseInt(strPageNum);
					}
					int startRowNum = 0;
					//������ �������� ���� �ǵ� - 0���� ����
					if (jpageNum!=1) {
						startRowNum = 1 +(jpageNum - 1) * PAGE_ROW_COUNT;
					}
					//������ �������� �� �ǵ�
					int endRowNum = jpageNum * PAGE_ROW_COUNT;
					
					//int rowCount = PAGE_ROW_COUNT;
					
					//���ǵ� ����
					int totalRow = Integer.parseInt(serviceTG.feedCount());
					int totlaPageCount = (int) Math.ceil(totalRow/(double) PAGE_ROW_COUNT);
					
					//�������� �Ѿ ���
					if (totlaPageCount < jpageNum) {
						return null;
					}
					
					HashMap<String, Object> param = new HashMap<String, Object>();
					param.put("startRowNum", Integer.toString(startRowNum));
					param.put("endRowNum", Integer.toString(endRowNum));
					param.put("feNum", feNum);
					
					list = serviceTG.myTagFeedList(param);
					System.out.println("myTagFeedList end");
					return new ResponseEntity<ArrayList<FeedDto>>(list, HttpStatus.OK);
				}
				
				//myLikeFeedNum
				@RequestMapping(value = "myLikeFeedNum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public String[] myLikeFeedNum(@RequestParam HashMap<String, String> param) {
					
					System.out.println("myLikeFeedNum => start");
					
					String[] dto = service.myLikeFeedNum(param);
					System.out.println(dto);
					
					
					System.out.println("myLikeFeedNum => end");
					
					return dto;
				}

				//myFeedNum
				@RequestMapping(value = "myFeedNum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public String[] myFeedNum(@RequestParam HashMap<String, String> param) {
					
					System.out.println("myFeedNum => start");
					
					String[] dto = service.myFeedNum(param);
					System.out.println(dto);
					
					
					System.out.println("myFeedNum => end");
					
					return dto;
				}

				//myTagFeedNum
				@RequestMapping(value = "myTagFeedNum", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public String[] myTagFeedNum(@RequestParam HashMap<String, String> param) {
					
					System.out.println("myTagFeedNum => start");
					
					String[] dto = service.myTagFeedNum(param);
					System.out.println(dto);
					
					
					System.out.println("myTagFeedNum => end");
					
					return dto;
				}

				//LikeFeedXY
				@RequestMapping(value = "LikeFeedXY", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public ArrayList<placeDto> LikeFeedXY(@RequestParam HashMap<String, String> param) {
					
					System.out.println("LikeFeedXY => start");
					
					ArrayList<placeDto> dto = service.LikeFeedXY(param);
					System.out.println(dto);
					
					
					System.out.println("LikeFeedXY => end");
					
					return dto;
				}
				
				//�±׻���
				@RequestMapping(value = "tagInsert", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public void tagInsert(@RequestParam HashMap<String, String> param) {
					//�ȷο찡 �ΰ��� �ƴҰ�� 
					if (!"".equals(param.get("follower"))) {
						serviceTG.tagInsert(param);
					}
					
				}
				
				
				//0609 �߰� end
				
				//�ؽ��±׻���
				@RequestMapping(value = "hashtagInsert", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public void hashtagInsert(@RequestParam HashMap<String, String> param) {
					
						serviceTG.hashtagInsert(param);
					
				}
				
				//0609 �߰� end
				
				//getFeNumByHashTag
				@RequestMapping(value = "getFeNumByHashTag", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public String[] getFeNumByHashTag(@RequestParam HashMap<String, String> param) {
					
					System.out.println("getFeNumByHashTag => start");
					
					String[] dto = service.getFeNumByHashTag(param);
					System.out.println(dto);
					
					
					System.out.println("getFeNumByHashTag => end");
					
					return dto;
				}
				
				//getHashTag
				@RequestMapping(value = "getHashTag", method = RequestMethod.POST,produces = "application/json; charset=utf8")
				@ResponseBody
				public ArrayList<HashTagDto> getHashTag(@RequestParam HashMap<String, String> param) {
					
					System.out.println("getHashTag => start");
					
					ArrayList<HashTagDto> dto = service.getHashTag(param);
					System.out.println(dto);
					
					System.out.println("getHashTag => end");
					
					return dto;
				}
	
			@RequestMapping("/payment")
			public String payment() {
				
				return "payment";
			}
				
			//�±׻���
			@RequestMapping(value = "insertMembership", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public void insertMembership(@RequestParam HashMap<String, String> param) {
				
				service.insertMembership(param);
				
			}

			@RequestMapping(value = "getMembership", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public int getMembership(@RequestParam HashMap<String, String> param) {
				
				int result = service.getMembership(param);
				if (result==0) {
					return 0;
				}
				
				return result;
				
			}
			
			//��� ����Ʈ
			@RequestMapping(value = "listComment", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public ArrayList<CommentDto> listComment(@RequestParam HashMap<String, String> param) {
				System.out.println("list param : "+param.get("feed_fenum"));
				
				ArrayList<CommentDto> list = new ArrayList<CommentDto>();
				list = service.listComment(param);
				if (list.size()==0) {
					return null;
				}
				
				return list;
			}
			//��� ��
			@RequestMapping(value = "countComment", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public int countComment(@RequestParam HashMap<String, String> param) {
				int result = service.countComment(param);
				System.out.println("countComment >>@#!@#@!#@!#>>"+result);
				return result;
			}
			
			//��� �Է�
			@RequestMapping(value = "insertComment", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public void insertComment(@RequestParam HashMap<String, String> param) {
				System.out.println("insert cmm param : "+param.get("comcontent"));
				System.out.println("insert cmm param : "+param.get("member_memid"));
				System.out.println("insert cmm param : "+param.get("feed_fenum"));
				
				param.put("memId", param.get("member_memid"));
				param.put("member_memid", service.getMemName(param).getMemName());
				
				service.insertComment(param);
			}
			
			//��� ����
			@RequestMapping(value = "updateComment", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public void updateComment(@RequestParam HashMap<String, String> param) {
				service.insertComment(param);
				
			}
			
			//��� ����
			@RequestMapping(value = "deleteComment", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public void deleteComment(@RequestParam HashMap<String, String> param) {
				
				service.deleteComment(param);
			}
			
			//���� �� �������� ������
			@RequestMapping(value="contentView", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public FeedDto contentView(@RequestParam HashMap<String, String> param, Model model) {
				System.out.println("@@@### contentView() start");
				System.out.println("#!@#!@#!@#>>>>>> "+param.get("fenum"));
				FeedDto dto = service.contentView(param);
				model.addAttribute("contentView", dto);
				
				System.out.println("CV ---> "+dto.getFecontent());
				System.out.println("@@@### contentView() end");
				return dto;
			}
			
			//���� �� �������� �̹��� 0613
			@RequestMapping(value="contentView_img", method = RequestMethod.POST,produces = "application/json; charset=utf8")
			@ResponseBody
			public ArrayList<FeedimgDto> contentView_img(@RequestParam HashMap<String, String> param, Model model) throws Exception {
				System.out.println("@@@### contentView_img() start");
				System.out.println("#!@#!@#!@#>>>>>> "+param.get("feed_fenum"));
				ArrayList<FeedimgDto> dto = service.contentView_img(param);
				
				for (int i = 0; i < dto.size(); i++) {
					String PullPath = dto.get(i).getUploadPath() + "\\"+ dto.get(i).getUuid() + "_" +dto.get(i).getFileName();
					dto.get(i).setPullPath(URLEncoder.encode(PullPath,"utf-8"));
				}
				model.addAttribute("contentView_img", dto);
				
				System.out.println("@@@### contentView_img() end");
				return dto;
			}
			//�ǵ� ����
					@RequestMapping(value = "modify" , method = RequestMethod.POST,produces = "application/json; charset=utf8")
					@ResponseBody
					public void modify(@RequestParam HashMap<String, String> param, Model model) { //������ ���� �ޱ����� http 
						System.out.println("$$$$$$$@@@### controller.modify() start");
						System.out.println("modify param !!: "+param.get("fenum"));
						System.out.println("modify param !!: "+param.get("fecontent"));
						service.modify(param);
						
						System.out.println("$$$$$$$@@@### controller.modify() end");
					}
			
					//�ǵ� ����
					@RequestMapping("/delete")
					@ResponseBody
					public void delete(@RequestParam HashMap<String, String> param,Model model) {
						System.out.println("@@@### Controller.delete() start");
						
						param.put("feed_fenum", param.get("fenum"));
						
						service.deleteimg(param);
						System.out.println("deleteimg");
						service.deletehastag(param);
						System.out.println("deletehastag");
						service.deletetag(param);
						System.out.println("deletetag");
						service.deletelike(param);
						System.out.println("deletelike");
						service.deletecomments(param);
						
						service.delete(param);
						
						System.out.println("@@@### Controller.delete() end");
					}
					
}
