package com.javalec.friendsourcing.dto;

public class FeedimgDto {
	private int imagenum;
	private int feed_fenum;
	private String fileName;
	private String uploadPath;
	private String uuid;
	private String pullPath;
	
	
	public String getPullPath() {
		return pullPath;
	}
	public void setPullPath(String pullPath) {
		this.pullPath = pullPath;
	}
	public int getImagenum() {
		return imagenum;
	}
	public void setImagenum(int imagenum) {
		this.imagenum = imagenum;
	}
	public int getFeed_fenum() {
		return feed_fenum;
	}
	public void setFeed_fenum(int feed_fenum) {
		this.feed_fenum = feed_fenum;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getUploadPath() {
		return uploadPath;
	}
	public void setUploadPath(String uploadPath) {
		this.uploadPath = uploadPath;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public FeedimgDto() {
		// TODO Auto-generated constructor stub
	}
	public FeedimgDto(int imagenum, int feed_fenum, String fileName, String uploadPath, String uuid) {
		super();
		this.imagenum = imagenum;
		this.feed_fenum = feed_fenum;
		this.fileName = fileName;
		this.uploadPath = uploadPath;
		this.uuid = uuid;
	}

}
